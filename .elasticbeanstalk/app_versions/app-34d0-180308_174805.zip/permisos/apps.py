from django.apps import AppConfig


class PermisosConfig(AppConfig):
    name = 'permisos'
