from django.apps import AppConfig


class EntidadesConfig(AppConfig):
    name = 'entidades'
