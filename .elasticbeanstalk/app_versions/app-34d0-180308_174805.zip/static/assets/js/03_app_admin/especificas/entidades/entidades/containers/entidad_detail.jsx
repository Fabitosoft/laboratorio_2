import React, {Component} from 'react';
import {connect} from "react-redux";
import * as actions from "../../../../../01_actions/01_index";
import CargarDatos from "../../../../../00_utilities/components/system/cargar_datos";
import ValidarPermisos from "../../../../../00_utilities/permisos/validar_permisos";
import {Titulo, SinObjeto} from "../../../../../00_utilities/templates/fragmentos";
import {permisosAdapter} from "../../../../../00_utilities/common";
import {
    ENTIDADES as permisos_view,
    CONTACTOS_ENTIDADES as bloque_1_permisos,
    ENTIDADES_EXAMENES as bloque_2_permisos
} from "../../../../../00_utilities/permisos/types";

import BloqueContactos from '../../contactos/components/contacto_entidad_list';
import BloqueEntidadExamenes from '../../examenes/components/entidad_examenes_list';

import {Tabs, Tab} from 'material-ui/Tabs';
import SwipeableViews from 'react-swipeable-views';

const styles = {
    headline: {
        fontSize: 24,
        paddingTop: 16,
        marginBottom: 12,
        fontWeight: 400,
    },
    slide: {
        padding: 10,
    },
};

class EntidadDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            slideIndex: 0,
        };
        this.cargarDatos = this.cargarDatos.bind(this);
        this.error_callback = this.error_callback.bind(this);
        this.notificar = this.notificar.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }


    handleChange = (value) => {
        this.setState({
            slideIndex: value,
        });
    };

    error_callback(error) {
        this.props.notificarErrorAjaxAction(error);
    }

    notificar(mensaje) {
        this.props.notificarAction(mensaje);
    }

    componentDidMount() {
        this.cargarDatos();
    }

    componentWillUnmount() {
        this.props.clearEntidades();
        this.props.clearExamenes();
    }

    cargarDatos() {
        const {id} = this.props.match.params;
        const {noCargando, cargando} = this.props;
        cargando();
        const cargarExamenes = () => this.props.fetchExamenes(id, () => noCargando(), this.error_callback);
        const cargarEntidad = () => this.props.fetchEntidad(id, cargarExamenes, this.error_callback);
        this.props.fetchMisPermisos(cargarEntidad, this.error_callback);

    }

    render() {
        const {entidad, mis_permisos, examenes} = this.props;
        const permisos = permisosAdapter(mis_permisos, permisos_view);
        const permisos_bloque_1 = permisosAdapter(mis_permisos, bloque_1_permisos);
        const permisos_bloque_2 = permisosAdapter(mis_permisos, bloque_2_permisos);

        if (!entidad) {
            return <SinObjeto/>
        }
        return (
            <ValidarPermisos can_see={permisos.detail} nombre='detalle entidad'>
                <Titulo>Detalle {entidad.nombre}</Titulo>
                <Tabs
                    onChange={this.handleChange}
                    value={this.state.slideIndex}
                >
                    <Tab label="Contactos" value={0}/>
                    <Tab label="Examenes" value={1}/>
                </Tabs>

                <SwipeableViews
                    index={this.state.slideIndex}
                    onChangeIndex={this.handleChange}
                >
                    <div style={styles.slide}>
                        <BloqueContactos
                            object_list={entidad.mis_contactos}
                            permisos_object={permisos_bloque_1}
                            {...this.props}
                        />
                    </div>
                    <div style={styles.slide}>
                        <BloqueEntidadExamenes
                            permisos_object={permisos_bloque_2}
                            object_list={entidad.mis_examenes}
                            examenes_list={examenes}
                            {...this.props}
                        />
                    </div>
                </SwipeableViews>
                <CargarDatos cargarDatos={this.cargarDatos}/>
            </ValidarPermisos>
        )
    }

}

function mapPropsToState(state, ownProps) {
    const {id} = ownProps.match.params;
    return {
        entidad: state.entidades[id],
        mis_permisos: state.mis_permisos,
        examenes: state.examenes
    }
}

export default connect(mapPropsToState, actions)(EntidadDetail)