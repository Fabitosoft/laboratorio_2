from django.apps import AppConfig


class ExamenesConfig(AppConfig):
    name = 'examenes'
